'use strict';
const Hapi = require('@hapi/hapi');

const data = [{pseudo: 'fred', password: 'xxx', email : 'fred@iut.fr'},
    {pseudo: 'paul', password: 'xxx', email : 'paul@iut.fr'}
];

const init = async () => {

    const server = Hapi.server({
        port: 3000,
        host: 'localhost'
    });

    server.route([
        {
        method: 'GET',
        path: '/api/membre',
        handler: function (request, h) {

            return data;

        }},
        {
            method: 'GET',
            path: '/api/membre/{pseudo}',
            handler: function (request, h) {
                const response = data.filter(element => element.pseudo == request.params.pseudo)

                return response.length==1 ? response[0]: {};

            }}
        ]);
    //attente du
    await server.start();
    console.log('Server running on %s', server.info.uri);
};

process.on('unhandledRejection', (err) => {

    console.log(err);
    process.exit(1);
});

init();


