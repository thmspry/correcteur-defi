const http = require('http');

const server = http.createServer(function(req, res) {
    res.iteHead(200);
    res.end('Salut tout le monde !');
});
server.listen(8080);
