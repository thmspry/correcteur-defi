'use strict';
const Hapi = require('@hapi/hapi');
const Inert = require('@hapi/inert');
const Vision = require('@hapi/vision');
const HapiSwagger = require('hapi-swagger');

const data = [{pseudo: 'fred', password: 'xxx', email : 'fred@iut.fr'},
    {pseudo: 'paul', password: 'xxx', email : 'paul@iut.fr'}
];

const init = async () => {

    const server = Hapi.server({
        port: 3000,
        host: 'localhost'
    });

    const swaggerOptions = {
        info: {
            title: 'Books API Documentation',
            version: '0.0.1',
        }
    };
    await server.register([
        Inert,
        Vision,
        {
            plugin: HapiSwagger,
            options: swaggerOptions
        }
    ]);
    server.route([
        {
        method: 'GET',
        path: '/api/membre',
            options: {
                description: 'Get books list',
                notes: 'Returns an array of membre',
                tags: ['api'],
                handler: function (request, h) {

                    return data;

                }
            }
        },
        {
            method: 'GET',
            path: '/api/membre/{pseudo}',
            handler: function (request, h) {
                const response = data.filter(element => element.pseudo == request.params.pseudo)

                return response.length==1 ? response[0]: {};

            }}
        ]);

    await server.start();
    console.log('Server running on %s', server.info.uri);
};

process.on('unhandledRejection', (err) => {

    console.log(err);
    process.exit(1);
});

init();


