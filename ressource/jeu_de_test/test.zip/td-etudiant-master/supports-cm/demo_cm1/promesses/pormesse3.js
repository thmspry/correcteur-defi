"use strict"
var promise1 = new Promise(function(resolve, reject) {
    setTimeout(function() {
        resolve('Un');
    }, 1000);
});

var promise2 = new Promise(function(resolve, reject) {
    setTimeout(function() {
        resolve('Deux');
    }, 1000);
});

promise1.then(res => {console.log(res); return promise2})
    .then(res => console.log(res));

