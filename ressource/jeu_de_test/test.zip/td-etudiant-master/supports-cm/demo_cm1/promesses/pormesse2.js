"use strict"
var promise1 = new Promise(function(resolve, reject) {
    if (Math.random() > 0.5)
        resolve("ok");
    else
        reject("pb");
});


promise1.then(res => console.log(res))
    .catch(res => console.log(res));

