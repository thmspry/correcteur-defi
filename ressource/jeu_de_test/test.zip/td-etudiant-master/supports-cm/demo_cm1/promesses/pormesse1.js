"use strict"
var promise1 = new Promise(function(resolve, reject) {
    setTimeout(function() {
        resolve('Un');
    }, 1000);
});
console.log(promise1);
promise1.then(res => console.log(res));
console.log("promise1");
console.log(promise1);