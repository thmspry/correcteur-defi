"use strict"
var promise1 = new Promise(function(resolve, reject) {
    setTimeout(function() {
        console.log("un")
        resolve('Un');
    }, Math.random()* 1000);
});

var promise2 = new Promise(function(resolve, reject) {
    setTimeout(function() {
        console.log("Deux");
        resolve('Deux');
    }, Math.random()* 1000);
});

Promise.race([promise1, promise2]).then(()=>console.log("done"));

