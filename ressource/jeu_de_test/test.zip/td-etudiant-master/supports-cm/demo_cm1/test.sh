body='{"pseudo":"stark-t","password":"pass","email":"dd"}'

curl --noproxy "*" -H "Content-Type: application/json"  -X POST -d $body http://localhost:3000/api/membre