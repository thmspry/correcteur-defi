const  Personne = function (prenom, nom) {
    this.type = "Personne";
    this.prenom = prenom || "John";
    this.nom = nom || "Doe";
}
Personne.prototype.getType = function() {
    return this.type;
}
Personne.prototype.getNomComplet = function() {
    return this.prenom + " " + this.nom
}
const Etudiant = function (prenom, nom, session) {
    Personne.call(this, prenom, nom);
    this.type = "Étudiant session : " + session;
}
Etudiant.prototype = new Personne(); // Héritage se fait ici
Etudiant.prototype.constructor = Etudiant; //chainage des constructeurs


const e = new Etudiant("Paul","Personne",2018);
console.log(e);
console.log(Etudiant);
console.log(Etudiant.prototype);

