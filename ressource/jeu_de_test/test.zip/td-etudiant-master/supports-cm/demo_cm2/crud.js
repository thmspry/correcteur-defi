const { Sequelize, DataTypes } = require('sequelize');

const sequelize = new Sequelize({
    dialect: 'sqlite',
    storage: 'demo_cm2/data/myDB.db'
});

async function init(){

    try {
        await sequelize.authenticate();
        console.log('Connection has been established successfully.');

        const User = sequelize.define('User', {
            email: DataTypes.STRING
        });

        const Todo = sequelize.define('Todo', {
            title: DataTypes.STRING,
            complete: DataTypes.BOOLEAN,

        });

        User.hasMany(Todo);
        Todo.belongsTo(User,{
            foreignKey: "UserId",
            allowNull: false});
        await User.sync({force: true}); //force recrée
        await Todo.sync({force: true});

        await User.create({email: 'toto0@toto.com'});
        await User.bulkCreate([{email: 'toto1@toto.com'},{email: 'toto2@toto.com'} ])

        await User.update({email: 'toto10@toto.com'}, {
            where: {
                email: 'toto1@toto.com'
            }
        });
        console.log(JSON.stringify(await User.findAll(), null, 2));
        await User.destroy( {
            where: {
                email: 'toto10@toto.com'
            }
        });
        console.log(JSON.stringify(await User.findAll(), null, 2));
        await Todo.create({title: "titre1", comlete:false, UserId: 1});

        console.log(JSON.stringify(await User.findAll({ include: Todo }), null, 2));
        console.log(JSON.stringify(await Todo.findAll({include: User}), null, 2));

    } catch (err){console.error(err)}
};

init();