const { Sequelize } = require('sequelize');

const sequelize = new Sequelize({
    dialect: 'sqlite',
    storage: 'demo_cm2/data/myDB.db'
});

async function init(){

    try {
        await sequelize.authenticate();
        console.log('Connection has been established successfully.');
    } catch (err){console.error(err)}
};

init();