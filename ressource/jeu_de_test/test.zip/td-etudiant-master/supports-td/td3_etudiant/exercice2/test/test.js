'use strict';

const Lab = require('@hapi/lab');
const {expect} = require('@hapi/code');
const {afterEach, beforeEach, describe, it} = exports.lab = Lab.script();
const {init} = require('../server');

describe('GET /', () => {
    let server;

    beforeEach(async () => {
        server = await init();
    });

    afterEach(async () => {
        await server.stop();
    });

    it('/api/v1/brasserie/responds with model', async () => {
        const res = await server.inject({
            method: 'get',
            url: '/api/v1/brasserie'
        });
        expect(res.statusCode).to.equal(200);
        expect(res.result).to.once.include([
            {id: 1, nameBreweries: 'brasserie1', city: 'city1'},
            {id: 2, nameBreweries: 'brasserie1', city: 'city2'}
        ]);
        expect([
            {id: 1, nameBreweries: 'brasserie1', city: 'city1'},
            {id: 2, nameBreweries: 'brasserie1', city: 'city2'}
        ]).to.once.include(res.result);
    });


    it('URL non gérée /', async () => {
        const res = await server.inject({
            method: 'get',
            url: '/'
        });
        expect(res.statusCode).to.equal(200);
        expect(res.result).to.equal('404 Error! Page Not Found!');
    });
    it('URL non gérée /api/v1/brasserie/ ', async () => {
        const res = await server.inject({
            method: 'get',
            url: '/api/v1/brasserie/'
        });
        expect(res.statusCode).to.equal(200);
        expect(res.result).to.equal('404 Error! Page Not Found!');
    });

    it('Recipération de la brasserdie d\'id 1', async () => {
        const res = await server.inject({
            method: 'get',
            url: '/api/v1/brasserie/1'
        });
        expect(res.statusCode).to.equal(200);
        expect(res.result).to.equal({id: 1, nameBreweries: 'brasserie1', city: 'city1'});
    });

    it('Récupération d\'une brasserie inexistante', async () => {
        const res = await server.inject({
            method: 'get',
            url: '/api/v1/brasserie/3'
        });
        expect(res.statusCode).to.equal(203);
        expect(res.result).to.equal({error: "not found"});
    });
});

describe('PUT /', () => {
    let server;

    beforeEach(async () => {
        server = await init();
    });

    afterEach(async () => {
        await server.stop();
    });

    it('Modification sans payload }', async () => {
        const res = await server.inject({
            method: 'put',
            url: '/api/v1/brasserie/1'
        });
        expect(res.statusCode).to.equal(203);
        expect(res.result).to.equal({error: "request error"});
    });
    it('Modification avec un payload non conforme ', async () => {
        const res = await server.inject({
            method: 'put',
            url: '/api/v1/brasserie/1',
            payload: {chat: 44}
        });
        expect(res.statusCode).to.equal(203);
        expect(res.result).to.equal({error: "request error"});
    });

    it('Identité', async () => {
        const res = await server.inject({
            method: 'put',
            url: '/api/v1/brasserie/1',
            payload : {id: 1, nameBreweries: 'brasserie1', city: 'city1'}
        });
        expect(res.statusCode).to.equal(200);
        expect(res.result).to.equal({id: 1, nameBreweries: 'brasserie1', city: 'city1'});
    });

    it('Modification fonctionnelle city1-> city2', async () => {
        const res = await server.inject({
            method: 'put',
            url: '/api/v1/brasserie/1',
            payload : {id: 1, nameBreweries: 'brasserie1', city: 'city2'}
        });
        expect(res.statusCode).to.equal(200);
        expect(res.result).to.equal({id: 1, nameBreweries: 'brasserie1', city: 'city2'});
    });
    it('Modification fonctionnelle city2-> city1', async () => {
        const res = await server.inject({
            method: 'put',
            url: '/api/v1/brasserie/1',
            payload : {id: 1, nameBreweries: 'brasserie1', city: 'city1'}
        });
        expect(res.statusCode).to.equal(200);
        expect(res.result).to.equal({id: 1, nameBreweries: 'brasserie1', city: 'city1'});
    });

    it('Modification non existant ', async () => {
        const res = await server.inject({
            method: 'put',
            url: '/api/v1/brasserie/44',
            payload : {id: 44, nameBreweries: 'brasserie44', city: 'city44'}
        });

        expect(res.statusCode).to.equal(203);
        expect(res.result).to.equal({error: "not exists"});

    });

    it('Consultation model ', async () => {
        const res = await server.inject({
            method: 'get',
            url: '/api/v1/brasserie'
        });

        expect(res.result).to.once.include([
            {id: 1, nameBreweries: 'brasserie1', city: 'city1'},
            {id: 2, nameBreweries: 'brasserie1', city: 'city2'}
        ]);
        expect([
            {id: 1, nameBreweries: 'brasserie1', city: 'city1'},
            {id: 2, nameBreweries: 'brasserie1', city: 'city2'}
        ]).to.once.include(res.result);
    });


});

describe('POST /', () => {
    let server;

    beforeEach(async () => {
        server = await init();
    });

    afterEach(async () => {
        await server.stop();
    });

    it("Ajout correct {id: 3, nameBreweries: 'brasserie3', city: 'city3'} ", async () => {
        const res = await server.inject({
            method: 'post',
            url: '/api/v1/brasserie',
            payload: '{"id":3,"nameBreweries":"brasserie3","city":"city3"}'
        });

        expect(res.statusCode).to.equal(201);
        expect(res.result).to.equal( {id: 3, nameBreweries: 'brasserie3', city: 'city3'})

    });
    it("Ajout existant {id: 3, nameBreweries: 'brasserie3', city: 'city3'} ", async () => {
        const res = await server.inject({
            method: 'post',
            url: '/api/v1/brasserie',
            payload: '{"id":3,"nameBreweries":"brasserie3","city":"city3"}'
        });

        expect(res.statusCode).to.equal(203);
        expect(res.result).to.equal( {error: "already exists"})

    });
    it("Ajout sans payload", async () => {
        const res = await server.inject({
            method: 'post',
            url: '/api/v1/brasserie',

        });

        expect(res.statusCode).to.equal(203);
        expect(res.result).to.equal( {error: "request error"})

    });
    it("Ajout avec mauvais payload", async () => {
        const res = await server.inject({
            method: 'post',
            url: '/api/v1/brasserie',
            payload: {}

        });

        expect(res.statusCode).to.equal(203);
        expect(res.result).to.equal( {error: "request error"})

    });
});


