var promise1 = (delay) => new Promise(function(resolve, reject) {
    setTimeout(function() {
        resolve(delay+' spend');
    }, delay);
});

//version promesse
promise1(1000)
    .then((res => console.log(res)))

//ceci ne marche pas car console.log n'est pas une promesse
const maPremiereMauvaiseFonctionAsync = async () => {
    await console.log( promise1(1001)); //pending
    await console.log( promise1(11));  //pending
}

//version correcte
const maPremiereFonctionAsync = async () => {
    console.log(await promise1(1000));
    console.log(await promise1(10));
}


//maPremiereMauvaiseFonctionAsync();
//maPremiereFonctionAsync();

//Une boucle for qui ne fonctionne pas
for(time of [promise1(2001), promise1(21)])
    console.log(time); //pending

//Une boucle sur des données asynchrones
const maDeuxiemeFonctionAsynchrone = async () => {
    for await (time of [promise1(2001), promise1(21)])
        console.log(time);
}

maDeuxiemeFonctionAsynchrone();